SECRET_KEY = '*&GJD%KDjy'
DEBUG = True

ENV_CONF = {
    'world_size': 12,
    'capacity': 10,
	'player1_home': (5,5),
	'player2_home': (6,6),
    'num_walls': 24,
    'num_jobs': 24,
    'value_range': (6,12),
    'max_steps': 200
}

REPLAY_DIR = "/replays"
TIMEOUT = 1.5
RETRY = 20

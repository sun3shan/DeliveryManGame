docker run -d -p 4444:5555 marathon python bin/run_server.py

export default {
  manifest: [
    {id: 'person1', src: '/images/person1.png'},   
    {id: 'person2', src: '/images/person2.png'},    
    {id: 'package', src: '/images/package.png'},
    {id: 'wall', src: '/images/wall.png'}
  ],
  rest: {
    'competition': '/competitions',
  }
}